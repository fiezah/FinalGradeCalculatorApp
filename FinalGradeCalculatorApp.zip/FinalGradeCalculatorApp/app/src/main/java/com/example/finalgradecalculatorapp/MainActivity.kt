import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var assignmentInput: EditText
    private lateinit var testInput: EditText
    private lateinit var examInput: EditText
    private lateinit var calculateButton: Button
    private lateinit var resetButton: Button
    private lateinit var gradeOutput: TextView
    private lateinit var resultOutput: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        assignmentInput = findViewById(R.id.assignmentInput)
        testInput = findViewById(R.id.testInput)
        examInput = findViewById(R.id.examInput)
        calculateButton = findViewById(R.id.calculateButton)
        resetButton = findViewById(R.id.resetButton)
        gradeOutput = findViewById(R.id.gradeOutput)
        resultOutput = findViewById(R.id.resultOutput)

        // Calculate button action
        calculateButton.setOnClickListener {
            calculateGrade()
        }

        // Reset button action
        resetButton.setOnClickListener {
            resetFields()
        }
    }

    private fun calculateGrade() {
        val assignment = assignmentInput.text.toString().toDoubleOrNull() ?: 0.0
        val test = testInput.text.toString().toDoubleOrNull() ?: 0.0
        val exam = examInput.text.toString().toDoubleOrNull() ?: 0.0

        val totalGrade = (assignment * 0.3) + (test * 0.3) + (exam * 0.4)

        gradeOutput.text = "Grade: %.2f".format(totalGrade)

        if (totalGrade > 50) {
            resultOutput.text = "Result: Pass"
        } else {
            resultOutput.text = "Result: Fail"
        }
    }

    private fun resetFields() {
        assignmentInput.text.clear()
        testInput.text.clear()
        examInput.text.clear()
        gradeOutput.text = "The Grade is shown here."
        resultOutput.text = "The Pass or Fail is shown here."
    }
}
